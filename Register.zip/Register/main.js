const { app, BrowserWindow, ipcMain } = require('electron')
const OktaAuth = require('@okta/okta-auth-js').OktaAuth

// Create an instance of the OktaAuth class with your issuer and client ID
const oktaAuth = new OktaAuth({
  issuer: 'https://your-okta-domain.com/oauth2/default',
  clientId: 'your-client-id',
  redirectUri: 'http://localhost:8080/login/callback',
  scopes: ['openid', 'profile', 'email']
})

// Declare global variables for the windows
let registerWindow
let appWindow

// Create the register window
function createRegisterWindow () {
  registerWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true
    }
  })

  // Load the HTML file for the register form
  registerWindow.loadFile('register.html')

  // Handle the window closed event
  registerWindow.on('closed', () => {
    registerWindow = null
  })
}

// Create the app window
function createAppWindow () {
  appWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true
    }
  })

  // Load the HTML file for the app interface
  appWindow.loadFile('app.html')

  // Handle the window closed event
  appWindow.on('closed', () => {
    appWindow = null
  })
}

// Listen for the open-app event from the register window
ipcMain.on('open-app', async (event, args) => {
  // Get the user information from the args
  const { username, password, fullname, gender, birthdate, phone, email } = args

  try {
    // Send the register request to Okta and create a new account
    const transaction = await oktaAuth.signUp({
      profile: {
        firstName: fullname.split(' ')[0],
        lastName: fullname.split(' ')[1],
        email: email,
        login: username,
        gender: gender,
        birthDate: birthdate,
        mobilePhone: phone
      },
      credentials: {
        password: {
          value: password
        }
      }
    })
    const { user } = transaction

    // Create the app window
    createAppWindow()

    // Send the user information to the app window
    appWindow.webContents.on('did-finish-load', () => {
      appWindow.webContents.send('app-ready', { user })
    })

    // Close the register window
    registerWindow.close()
  } catch (error) {
    // Handle the register error
    console.error(error)
    event.sender.send('register-error', error.message)
  }
})

// Handle the app ready event
app.whenReady().then(() => {
  // Create the register window
  createRegisterWindow()

  // Handle the app activate event
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createRegisterWindow()
    }
  })
})

// Handle the app window all closed event
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
