// Import the Okta Auth JS SDK
const OktaAuth = require('@okta/okta-auth-js').OktaAuth

// Create an instance of the OktaAuth class with your issuer and client ID
const oktaAuth = new OktaAuth({
  issuer: 'https://your-okta-domain.com/oauth2/default',
  clientId: 'your-client-id',
  redirectUri: 'http://localhost:8080/login/callback',
  scopes: ['openid', 'profile', 'email']
})

// Get the elements from the HTML file
const usernameInput = document.getElementById('username')
const passwordInput = document.getElementById('password')
const fullnameInput = document.getElementById('fullname')
const genderSelect = document.getElementById('gender')
const birthdateInput = document.getElementById('birthdate')
const phoneInput = document.getElementById('phone')
const emailInput = document.getElementById('email')
const registerButton = document.getElementById('register-button')
const errorMessage = document.getElementById('error-message')

// Add an event listener to the register button
registerButton.addEventListener('click', async () => {
  // Get the user information from the input fields
  const username = usernameInput.value
  const password = passwordInput.value
  const fullname = fullnameInput.value
  const gender = genderSelect.value
  const birthdate = birthdateInput.value
  const phone = phoneInput.value
  const email = emailInput.value

  // Validate the input
  if (username && password && fullname && gender && birthdate && phone && email) {
    try {
      // Send the register request to Okta and create a new account
      const transaction = await oktaAuth.signUp({
        profile: {
          firstName: fullname.split(' ')[0],
          lastName: fullname.split(' ')[1],
          email: email,
          login: username,
          gender: gender,
          birthDate: birthdate,
          mobilePhone: phone
        },
        credentials: {
          password: {
            value: password
          }
        }
      })
      const { user } = transaction

      // Send the user information to the main process
      ipcRenderer.send('open-app', { user })
    } catch (error) {
      // Handle the register error
      console.error(error)
      errorMessage.textContent = error.message
    }
  } else {
    // Show an alert message if the input is empty
    alert('Please enter all the required information')
  }
})
