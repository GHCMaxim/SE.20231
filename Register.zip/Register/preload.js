const { ipcRenderer } = require('electron')

// Send the user information to the main process when the register button is clicked
document.getElementById('register-button').addEventListener('click', () => {
  // Get the user information from the input fields
  const username = document.getElementById('username').value
  const password = document.getElementById('password').value
  const fullname = document.getElementById('fullname').value
  const gender = document.getElementById('gender').value
  const birthdate = document.getElementById('birthdate').value
  const phone = document.getElementById('phone').value
  const email = document.getElementById('email').value

  // Validate the input
  if (username && password && fullname && gender && birthdate && phone && email) {
    // Send the open-app event with the user information as arguments
    ipcRenderer.send('open-app', { username, password, fullname, gender, birthdate, phone, email })
  } else {
    // Show an alert message if the input is empty
    alert('Vui lòng nhập đầy đủ thông tin')
  }
})

// Listen for the register-error event from the main process and show the error message
ipcRenderer.on('register-error', (event, args) => {
  // Get the error message from the args
  const errorMessage = args

  // Show the error message in a div element
  document.getElementById('error-message').textContent = errorMessage
})
