const { app, BrowserWindow, ipcMain } = require('electron')
const OktaAuth = require('@okta/okta-auth-js').OktaAuth

// Create an instance of the OktaAuth class with your issuer and client ID
const oktaAuth = new OktaAuth({
  issuer: 'https://your-okta-domain.com/oauth2/default',
  clientId: 'your-client-id',
  redirectUri: 'http://localhost:8080/login/callback',
  scopes: ['openid', 'profile', 'email']
})

// Declare global variables for the windows
let loginWindow
let appWindow

// Create the login window
function createLoginWindow () {
  loginWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true
    }
  })

  // Load the HTML file for the login screen
  loginWindow.loadFile('login.html')

  // Handle the window closed event
  loginWindow.on('closed', () => {
    loginWindow = null
  })
}

// Create the app window
function createAppWindow () {
  appWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true
    }
  })

  // Load the HTML file for the app interface
  appWindow.loadFile('app.html')

  // Handle the window closed event
  appWindow.on('closed', () => {
    appWindow = null
  })
}

// Listen for the open-app event from the login window
ipcMain.on('open-app', async (event, args) => {
  // Get the username and password from the args
  const { username, password } = args

  try {
    // Send the login request to Okta and get the authentication token and user information
    const transaction = await oktaAuth.signInWithCredentials({ username, password })
    const { sessionToken, user } = transaction

    // Create the app window
    createAppWindow()

    // Send the authentication token and user information to the app window
    appWindow.webContents.on('did-finish-load', () => {
      appWindow.webContents.send('app-ready', { sessionToken, user })
    })

    // Close the login window
    loginWindow.close()
  } catch (error) {
    // Handle the login error
    console.error(error)
    event.sender.send('login-error', error.message)
  }
})

// Handle the app ready event
app.whenReady().then(() => {
  // Create the login window
  createLoginWindow()

  // Handle the app activate event
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createLoginWindow()
    }
  })
})

// Handle the app window all closed event
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
