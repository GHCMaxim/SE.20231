// Import the Okta Auth JS SDK
const OktaAuth = require('@okta/okta-auth-js').OktaAuth

// Create an instance of the OktaAuth class with your issuer and client ID
const oktaAuth = new OktaAuth({
  issuer: 'https://your-okta-domain.com/oauth2/default',
  clientId: 'your-client-id',
  redirectUri: 'http://localhost:8080/login/callback',
  scopes: ['openid', 'profile', 'email']
})

// Get the elements from the HTML file
const usernameInput = document.getElementById('username')
const passwordInput = document.getElementById('password')
const loginButton = document.getElementById('login-button')
const errorMessage = document.getElementById('error-message')

// Add an event listener to the login button
loginButton.addEventListener('click', async () => {
  // Get the username and password from the input fields
  const username = usernameInput.value
  const password = passwordInput.value

  // Validate the input
  if (username && password) {
    try {
      // Send the login request to Okta and get the authentication token and user information
      const transaction = await oktaAuth.signInWithCredentials({ username, password })
      const { sessionToken, user } = transaction

      // Store the authentication token and user information in the local storage
      localStorage.setItem('sessionToken', sessionToken)
      localStorage.setItem('user', JSON.stringify(user))

      // Redirect to the app page
      window.location.href = 'app.html'
    } catch (error) {
      // Handle the login error
      console.error(error)
      errorMessage.textContent = error.message
    }
  } else {
    // Show an alert message if the input is empty
    alert('Please enter your username and password')
  }
})
