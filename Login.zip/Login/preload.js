const { ipcRenderer } = require('electron')

// Send the username and password to the main process when the login button is clicked
document.getElementById('login-button').addEventListener('click', () => {
  // Get the username and password from the input fields
  const username = document.getElementById('username').value
  const password = document.getElementById('password').value

  // Validate the input
  if (username && password) {
    // Send the open-app event with the username and password as arguments
    ipcRenderer.send('open-app', { username, password })
  } else {
    // Show an alert message if the input is empty
    alert('Please enter your username and password')
  }
})

// Listen for the login-error event from the main process and show the error message
ipcRenderer.on('login-error', (event, args) => {
  // Get the error message from the args
  const errorMessage = args

  // Show the error message in a div element
  document.getElementById('error-message').textContent = errorMessage
})
